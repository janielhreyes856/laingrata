# La Ingrata Camden — Static Site

Single-file static site. Deploy anywhere.

## Deploy to Vercel
1. Push this folder to a GitHub repo
2. Import the repo at https://vercel.com/new
3. Framework preset: **Other** (no build needed)
4. Click Deploy

## Deploy to GitHub Pages
1. Push to a GitHub repo
2. Settings → Pages → Source: `main` branch, `/root`

## Local preview
Open `index.html` in a browser, or run:
```
npx serve .
```
